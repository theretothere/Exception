/**
 * Created with IntelliJ IDEA.
 * Description:
 * User: GaoBo
 * Date: 2020-10-27
 * Time: 8:41
 */
class MyException extends Exception{
    public MyException() {
    }

    public MyException(String message) {
        super(message);
    }
}


public class TestDemo {

    public static void func2(int x) throws MyException {
        if(x == 10) {
            throw new MyException("x==10");
        }
    }


    public static void main(String[] args) {

        //func2(10);

        /*try {
            func2(10);
        }catch (MyException e) {
            e.printStackTrace();
        }*/
    }



    public static double func(int x,int y) throws ArithmeticException{
        if(y == 0) {
            throw new ArithmeticException("除了个0");
        }
        return x*1.0 / y;
    }
    public static void main1(String[] args) {
        try {
            System.out.println(func(10, 0));
        }catch (ArithmeticException e) {
            e.printStackTrace();
            System.out.println("除数为0！");
        }
    }
}
