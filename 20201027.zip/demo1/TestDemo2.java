package demo1;

import java.io.UnsupportedEncodingException;
import java.util.Arrays;

/**
 * Created with IntelliJ IDEA.
 * Description:
 * User: GaoBo
 * Date: 2020-10-27
 * Time: 10:37
 */
public class TestDemo2 {

    public static void main(String[] args) {
        /*String str = "hello\\bit\\Java";
        String[] ret = str.split("\\\\");
        for (String s : ret) {
            System.out.println(s);
        }*/
        /*String str="Java30-split#bit";
        String[] ret = str.split(" |-|#");
        for (String s : ret) {
            System.out.println(s);
        }*/
        String str = "name=zhangsan&age=18";
        String[] ret1 = str.split("&");
        //name=zhangsan
        //age=18
        for (String s1 : ret1) {
            String[] ret2 = s1.split("=");
            for (String s2 :ret2) {
                System.out.println(s2);
            }
        }

    }

    public static void main6(String[] args) {
        String str = "hellobitbitabcd";
        System.out.println(str.replace("it","xx"));
        //从后往前找
        /*System.out.println(str.lastIndexOf("bit",7));
        System.out.println(str.contains("bit"));
        System.out.println(str.indexOf("bit",6));
        */
    }

    public static void main5(String[] args) {
        String str = "abcdefg";
        String str2 = "abcde";
        System.out.println(str.equals(str2));
        //equalsIgnoreCase 忽略大小写进行比较
        System.out.println(str.equalsIgnoreCase(str2));
        //str和str2比较
        int ret = str.compareTo(str2);
        System.out.println(ret);
    }


    public static boolean isNumberChar(String str) {
        for (int i = 0; i < str.length(); i++) {
            if(str.charAt(i) < '0' || str.charAt(i) > '9') {
                return false;
            }
        }
        return true;
    }

    public static void main4(String[] args) throws UnsupportedEncodingException {
//        String str = "123456";
//        System.out.println(isNumberChar(str));
//
       /* byte[] bytes = {97,98,99,100};
        String str = new String(bytes,8);
        System.out.println(str);*/

        /*String str = "高博";
        byte[] bytes = str.getBytes("GBK");
        System.out.println(Arrays.toString(bytes));
*/
    }


    public static void main3(String[] args) {
        char[] array = {'a','b','c'};
        String str = new String(array,1,2);
        System.out.println(str);

        String str2 = "abcdef";
        char ch = str2.charAt(2);
        System.out.println(ch);
        System.out.println(str2.length());

        char[] array2 = str2.toCharArray();
        System.out.println(Arrays.toString(array2));

    }

    public static void main1(String[] args) {
        String str = "hello";
        for (int i = 0; i < 10; i++) {
            str += i;
        }
        System.out.println(str);
    }
}
