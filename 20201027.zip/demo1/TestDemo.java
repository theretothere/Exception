package demo1;

import java.lang.reflect.Field;

/**
 * Created with IntelliJ IDEA.
 * Description:
 * User: GaoBo
 * Date: 2020-10-27
 * Time: 9:23
 */
class Person {
    private String name;

    private Person() {
    }
}


public class TestDemo {

    public static void main(String[] args) {
        String str = "hello";
        for (int i = 0; i < 10; i++) {
            str += i;
        }
        System.out.println(str);
    }

    public static void main5(String[] args) throws NoSuchFieldException, IllegalAccessException {
        String str = "hello";
        Class cl = String.class;
        Field field = cl.getDeclaredField("value");
        field.setAccessible(true);

        char[] value = (char[]) field.get(str);
        // 修改 value 的值
        value[0] = 'H';
        System.out.println(str);

    }

    public static void main4(String[] args) {
        String str1 = "hello";
        String str2 = new String("hello").intern();
        System.out.println(str1 == str2);
    }



    public static void main3(String[] args) {
        /*String str1 = "hello";
        String str2 = new String("hello").intern();

        System.out.println(str1 == str2);*/
        String str1 = "Hello";
        String str2 = str1;
        System.out.println(str1);
        System.out.println(str2);
        str1 = "bit";
        System.out.println(str1);
        System.out.println(str2);
    }

    public static void main2(String[] args) {
        String str1 = "hello";
        String str2 = new String("hello");
        System.out.println(str1 == str2);
        System.out.println(str1.equals(str2));

        String str3 = "he"+"llo";//"hello"
        System.out.println(str1 == str3);

        String str4 = "he";
        String str5 = str4+"llo";//
        System.out.println(str1 == str5);

        String str6 = new String("he")+"llo";
        System.out.println(str6 == str1);

    }
    public static void main1(String[] args) {
        String str1 = "hello";

        String str2 = new String("hello");

        char[] array = {'h','e','l','l','o'};
        String str3 = new String(array);
    }
}
